"""Pure-geometry helpers shared by the server scripts and the Modal functions.

Only numpy / scipy / shapely: no torch, so everything here can be tested on the
server.

  centerline_boxes   OSM road centre-lines -> small "this is road" exemplar boxes
  boxes_to_cxcywh    map-unit boxes -> SAM 3's normalized [cx, cy, w, h]
  fill_small_holes   post-processing: fill small enclosed holes in a road mask
  iou, boundary_f1   scoring a predicted road mask against a ground-truth mask
"""

import math

import numpy as np


# ---------------------------------------------------------------- prompt boxes
def centerline_boxes(lines, center, units_per_m, radii_m=(15.0, 11.0, 19.0),
                     half_m=2.5, max_boxes=4, min_sep_m=6.0, bounds=None):
    """Exemplar boxes on road centre-lines, away from the intersection itself.

    lines        iterable of shapely LineStrings (any metric-like CRS)
    center       shapely Point, the clip / intersection centre
    units_per_m  CRS units per ground metre (1 for UTM; 1/cos(lat) for EPSG:3857)
    radii_m      rings around the centre on which to look for road; the first
                 ring that yields points wins, so boxes sit on the approach legs
    half_m       half-width of each box (2.5 m -> a 5 m square, inside a lane)
    bounds       (minx, miny, maxx, maxy): boxes must lie fully inside

    Returns a list of (minx, miny, maxx, maxy) in the lines' CRS.
    """
    from shapely.geometry import MultiPoint, Point

    lines = [ln for ln in lines if ln is not None and not ln.is_empty]
    if not lines:
        return []
    h = half_m * units_per_m
    for r in radii_m:
        ring = center.buffer(r * units_per_m, quad_segs=32).exterior
        pts = []
        for ln in lines:
            inter = ln.intersection(ring)
            if inter.is_empty:
                continue
            geoms = getattr(inter, "geoms", [inter])
            for g in geoms:
                if isinstance(g, Point):
                    pts.append(g)
                elif not g.is_empty:              # a line lying along the ring
                    pts.append(g.representative_point())
        kept = []
        for p in pts:
            if all(p.distance(q) >= min_sep_m * units_per_m for q in kept):
                kept.append(p)
        boxes = []
        for p in kept:
            b = (p.x - h, p.y - h, p.x + h, p.y + h)
            if bounds is None or (b[0] >= bounds[0] and b[1] >= bounds[1]
                                  and b[2] <= bounds[2] and b[3] <= bounds[3]):
                boxes.append(b)
        if boxes:
            return boxes[:max_boxes]
    return []


def boxes_to_cxcywh(boxes, bounds):
    """Map-unit boxes -> normalized [cx, cy, w, h] (origin top-left, y down)."""
    minx, miny, maxx, maxy = bounds
    W, H = maxx - minx, maxy - miny
    out = []
    for x0, y0, x1, y1 in boxes:
        out.append([float(((x0 + x1) / 2 - minx) / W), float((maxy - (y0 + y1) / 2) / H),
                    float((x1 - x0) / W), float((y1 - y0) / H)])
    return out


def cxcywh_to_pixels(box, width, height):
    cx, cy, w, h = box
    return (int(round((cx - w / 2) * width)), int(round((cy - h / 2) * height)),
            int(round((cx + w / 2) * width)), int(round((cy + h / 2) * height)))


def mercator_units_per_m(lat):
    return 1.0 / math.cos(math.radians(lat))


# ------------------------------------------------------------- post-processing
def fill_small_holes(mask, px_m2, max_m2):
    """Fill non-road holes fully enclosed by road and smaller than max_m2.

    Removes parked cars, crosswalk paint and manholes that SAM 3 leaves out of
    "road" but the labels count as drivable. Holes touching the image frame are
    never filled (they are real off-road areas, e.g. sidewalk corners), and holes
    of max_m2 or more are kept (refuge islands, medians)."""
    from scipy import ndimage

    if not max_m2 or max_m2 <= 0:
        return mask
    m = mask.astype(bool)
    lab, n = ndimage.label(~m)                       # 4-connected holes
    if n == 0:
        return m
    sizes = ndimage.sum(~m, lab, index=np.arange(1, n + 1)) * px_m2
    edge = np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))
    fill = np.zeros(n + 1, bool)
    fill[1:] = sizes < max_m2
    fill[edge] = False
    fill[0] = False
    return m | fill[lab]


# ------------------------------------------------------------------- scoring
def iou(pred, gt):
    pred, gt = pred.astype(bool), gt.astype(bool)
    union = np.logical_or(pred, gt).sum()
    return float(np.logical_and(pred, gt).sum() / union) if union else 1.0


def _boundary(mask, border_px=2):
    """Edge pixels of a mask, ignoring the image frame (a mask touching the
    frame edge is not a curb)."""
    from scipy import ndimage

    m = mask.astype(bool)
    edge = m & ~ndimage.binary_erosion(m, structure=np.ones((3, 3), bool), border_value=1)
    if border_px:
        edge[:border_px, :] = edge[-border_px:, :] = False
        edge[:, :border_px] = edge[:, -border_px:] = False
    return edge


def boundary_f1(pred, gt, tol_px):
    """Boundary F1 (Csurka et al.): share of predicted curb pixels within tol of a
    true curb pixel (precision) and vice versa (recall)."""
    from scipy import ndimage

    bp, bg = _boundary(pred), _boundary(gt)
    if not bp.any() and not bg.any():
        return 1.0, 1.0, 1.0
    if not bp.any() or not bg.any():
        return 0.0, 0.0, 0.0
    d_to_gt = ndimage.distance_transform_edt(~bg)
    d_to_pred = ndimage.distance_transform_edt(~bp)
    prec = float((d_to_gt[bp] <= tol_px).mean())
    rec = float((d_to_pred[bg] <= tol_px).mean())
    f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0.0
    return prec, rec, f1

"""Fetch 50 m x 50 m clips around each intersection (Modal, CPU).

  source A    -> candidate A: Google basemap, zoom 22, via segment-geospatial
                 (same call as the reference repo)
  source B    -> candidate B: Cook County CookOrtho2025, bands R,G,B
  source pool -> Cook County R,G,B,NIR, used only for the canopy (NDVI) screen

Every clip is written as a georeferenced GeoTIFF (EPSG:3857) to the `cc-imagery`
volume under /<subdir>/crosswalk_<id>.tif, and a per-clip summary CSV is written
locally.

Usage (from ~/crosswalk/pipeline, with MODAL_ENVIRONMENT=cook):
  uv run modal run cc_fetch.py --source pool --input ../data/sample/candidates.csv \
      --out-csv ../data/sample/pool_ndvi.csv
  uv run modal run cc_fetch.py --source B --input ../data/sample/sample.csv \
      --out-csv ../logs/fetch_B.csv
"""

import modal

from cc_common import (
    COOK_IMAGESERVER, IMAGERY_VOLUME, NDVI_VEG, SUBDIRS, bbox_lonlat, crosswalk_id,
)

app = modal.App("cc-crosswalk-fetch")
imagery = modal.Volume.from_name(IMAGERY_VOLUME, create_if_missing=True)

cook_image = (
    modal.Image.debian_slim(python_version="3.11")
    .pip_install("requests", "numpy", "rasterio", "pyproj")
    .add_local_python_source("cc_common")
)

# Same base image the reference repo uses for its Google tile fetch.
google_image = (
    modal.Image.from_registry("gboeing/osmnx:latest")
    .pip_install("segment-geospatial", "rasterio")
    .env({"TINI_SUBREAPER": "1"})
    .add_local_python_source("cc_common")
)


def _summary(path, cid, lat, lon):
    import numpy as np
    import rasterio

    with rasterio.open(path) as src:
        res_x = abs(src.transform.a)
        out = {
            "id": cid, "lat": lat, "lon": lon, "path": path,
            "width": src.width, "height": src.height, "bands": src.count,
            # ground metres per pixel (Web Mercator units scaled by cos(lat))
            "ground_res_m": res_x * np.cos(np.radians(lat)),
        }
        if src.count >= 4:
            r = src.read(1).astype("float32")
            nir = src.read(4).astype("float32")
            ndvi = (nir - r) / (nir + r + 1e-6)
            out["ndvi_mean"] = float(ndvi.mean())
            out["veg_frac"] = float((ndvi > NDVI_VEG).mean())
    return out


@app.function(image=cook_image, volumes={"/imagery": imagery},
              max_containers=8, timeout=600, retries=2)
def fetch_cook(lat: float, lon: float, subdir: str, bands: str, size: int = 1024):
    import os
    import time

    import numpy as np
    import rasterio
    import requests
    from pyproj import Transformer
    from rasterio.io import MemoryFile
    from rasterio.transform import from_bounds

    cid = crosswalk_id(lat, lon)
    w, s, e, n = bbox_lonlat(lat, lon)
    t = Transformer.from_crs("EPSG:4326", "EPSG:3857", always_xy=True)
    x0, y0 = t.transform(w, s)
    x1, y1 = t.transform(e, n)

    params = {
        "bbox": f"{x0},{y0},{x1},{y1}", "bboxSR": 3857, "imageSR": 3857,
        "size": f"{size},{size}", "format": "tiff", "pixelType": "U8",
        "bandIds": bands, "interpolation": "RSP_BilinearInterpolation", "f": "image",
    }
    for attempt in range(4):
        r = requests.get(f"{COOK_IMAGESERVER}/exportImage", params=params, timeout=120)
        if r.ok and r.headers.get("content-type", "").startswith("image"):
            break
        time.sleep(2 ** attempt)
    else:
        raise RuntimeError(f"exportImage failed for {cid}: {r.status_code} {r.text[:200]}")

    with MemoryFile(r.content) as mf, mf.open() as src:
        data = src.read()

    # Always write our own georeferencing from the requested bbox, so the clip is
    # correct even if the server's TIFF tags are missing or in another SR.
    os.makedirs(f"/imagery/{subdir}", exist_ok=True)
    path = f"/imagery/{subdir}/crosswalk_{cid}.tif"
    profile = dict(driver="GTiff", width=data.shape[2], height=data.shape[1],
                   count=data.shape[0], dtype="uint8", crs="EPSG:3857",
                   transform=from_bounds(x0, y0, x1, y1, data.shape[2], data.shape[1]),
                   compress="deflate")
    with rasterio.open(path, "w", **profile) as dst:
        dst.write(data.astype(np.uint8))
    imagery.commit()
    return _summary(path, cid, lat, lon)


@app.function(image=google_image, volumes={"/imagery": imagery},
              max_containers=20, timeout=600, retries=2)
def fetch_google(lat: float, lon: float, subdir: str):
    import os

    from samgeo import tms_to_geotiff

    cid = crosswalk_id(lat, lon)
    w, s, e, n = bbox_lonlat(lat, lon)
    os.makedirs(f"/imagery/{subdir}", exist_ok=True)
    path = f"/imagery/{subdir}/crosswalk_{cid}.tif"
    # Same call as the reference repo: zoom 22 "Satellite" tiles, output in EPSG:3857
    tms_to_geotiff(output=path, bbox=[w, s, e, n], crs="EPSG:3857", zoom=22,
                   source="Satellite", overwrite=True, quiet=True)
    imagery.commit()
    return _summary(path, cid, lat, lon)


@app.local_entrypoint()
def main(source: str, input: str, out_csv: str, limit: int = 0, subdir: str = ""):
    """--subdir overrides the target folder (e.g. pilot_B for the prompt pilot)."""
    import pandas as pd

    df = pd.read_csv(input)
    if limit:
        df = df.head(limit)
    lats, lons = df["lat"].round(6).tolist(), df["lon"].round(6).tolist()
    subdir = subdir or SUBDIRS[source]
    print(f"Fetching {len(df)} clips for source {source} -> /{subdir}")

    if source == "A":
        results = fetch_google.map(lats, lons, kwargs={"subdir": subdir},
                                   return_exceptions=True)
    else:
        bands = "0,1,2" if source == "B" else "0,1,2,3"
        results = fetch_cook.map(lats, lons, kwargs={"subdir": subdir, "bands": bands},
                                 return_exceptions=True)

    rows = []
    for (la, lo), r in zip(zip(lats, lons), results):
        if isinstance(r, Exception):
            rows.append({"id": crosswalk_id(la, lo), "lat": la, "lon": lo, "error": repr(r)})
        else:
            rows.append(r)
    out = pd.DataFrame(rows)
    out.to_csv(out_csv, index=False)
    n_err = int(out["error"].notna().sum()) if "error" in out else 0
    print(f"done: {len(out) - n_err} ok, {n_err} failed -> {out_csv}")

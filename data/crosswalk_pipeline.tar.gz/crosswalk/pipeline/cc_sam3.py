"""SAM 3 road segmentation core, shared by cc_segment.py and cc_benchmark.py.

For each image the backbone is run once; each (text, boxes) prompt then costs
one decoder pass, and results are cached, so a grid of settings is cheap.

Settings (a Config):
  mode       text      text prompt only
             box       exemplar boxes on OSM road centre-lines, no text
             text+box  both
  fusion     instance  union of kept instance masks (what SAM 3's processor returns)
             semantic  SAM 3's semantic-head probability x presence score
             fused     max(instance prob x score, semantic prob) x presence
                       (SegEarth-OV3, Li et al. 2025), thresholded at prob_thd
  prompts    positive phrases; their maps are combined by max
  negatives  competing phrases (e.g. sidewalk); a pixel is road only where the
             road probability beats every negative (semantic / fused only)
  rule       positive    road = road probability > prob_thd (default)
             complement  road = no non-drivable phrase (the negatives) exceeds
                         prob_thd; matches labels drawn as "everything that is
                         not sidewalk / building / park" (semantic / fused only)
  fill_holes_m2  fill enclosed non-road holes smaller than this (parked cars,
             crosswalk paint, manholes); 0 = off. Applied by the caller, which
             knows the ground pixel size (cc_geom.fill_small_holes)
"""

from dataclasses import dataclass

import numpy as np

MODES = ("text", "box", "text+box")
FUSIONS = ("instance", "semantic", "fused")
RULES = ("positive", "complement")


@dataclass(frozen=True)
class Config:
    mode: str = "text"
    fusion: str = "fused"
    prompts: tuple = ("road",)
    negatives: tuple = ()
    prob_thd: float = 0.3
    confidence: float = 0.5
    rule: str = "positive"
    fill_holes_m2: float = 0.0

    def __post_init__(self):
        assert self.mode in MODES, self.mode
        assert self.fusion in FUSIONS, self.fusion
        assert self.rule in RULES, self.rule
        if self.rule == "complement":
            assert self.negatives, "complement rule needs negatives (the non-drivable phrases)"
            assert self.fusion != "instance", "complement rule needs semantic or fused fusion"

    @property
    def key(self):
        """Stable name; settings at their defaults add nothing, so earlier run keys still match."""
        def j(xs):
            return "+".join(x.replace(" ", "-") for x in xs)
        if self.rule == "complement":
            core = f"{self.mode}__{self.fusion}__not-{j(self.negatives)}"
        else:
            pos = j(self.prompts) if self.mode != "box" else "boxes"
            neg = f"__neg-{j(self.negatives)}" if self.negatives else ""
            core = f"{self.mode}__{self.fusion}__{pos}{neg}"
        fill = f"_fill{self.fill_holes_m2:g}" if self.fill_holes_m2 else ""
        return f"{core}__t{self.prob_thd:g}_c{self.confidence:g}{fill}"


def config_grid(modes, fusions, prompt_sets, negative_sets, prob_thd, confidence,
                prob_thds=None, fill_holes=(0.0,), rules=("positive",)):
    """All valid combinations. Box-only mode ignores prompt sets; instance fusion
    ignores negatives, thresholds and the complement rule; the complement rule
    ignores prompt sets and needs a non-empty negative set."""
    thds = list(prob_thds) if prob_thds else [prob_thd]
    out = []
    for rule in rules:
        for mode in modes:
            for fusion in fusions:
                if rule == "complement" and fusion == "instance":
                    continue
                psets = [("road",)] if (mode == "box" or rule == "complement") else prompt_sets
                nsets = [()] if fusion == "instance" else negative_sets
                if rule == "complement":
                    nsets = [n for n in nsets if n]
                tset = [prob_thd] if fusion == "instance" else thds
                for ps in psets:
                    for ns in nsets:
                        for t in tset:
                            for fh in fill_holes:
                                out.append(Config(mode, fusion, tuple(ps), tuple(ns), float(t),
                                                  confidence, rule, float(fh)))
    return list(dict.fromkeys(out))


@dataclass
class ClassMaps:
    inst_union: np.ndarray       # bool, union of kept instance masks
    inst_prob: np.ndarray        # float, max over kept instances of mask prob x score
    sem_prob: np.ndarray         # float, semantic head probability
    presence: float
    n_inst: int
    max_score: float


def load(checkpoint_path, device="cuda", delta=None):
    """Build SAM 3 from `checkpoint_path`; `delta` is an optional fine-tuned
    segmentation-head file written by cc_finetune.py (absolute path)."""
    from sam3.model.sam3_image_processor import Sam3Processor
    from sam3.model_builder import build_sam3_image_model

    model = build_sam3_image_model(checkpoint_path=checkpoint_path, load_from_HF=False,
                                   device=device)
    if delta:
        import torch

        d = torch.load(delta, map_location="cpu", weights_only=False)
        model.segmentation_head.load_state_dict(d["segmentation_head"], strict=True)
        model.segmentation_head.to(device)
        print(f"loaded fine-tuned segmentation head {delta} ({d.get('meta', {})})")
    model.eval()
    return model, Sam3Processor(model, device=device)


class ImageSession:
    """Backbone features for one image plus a cache of per-prompt maps."""

    def __init__(self, model, proc, rgb):
        from PIL import Image

        self.model, self.proc = model, proc
        self.h, self.w = rgb.shape[:2]
        self.state = proc.set_image(Image.fromarray(rgb))
        self._cache = {}

    def class_maps(self, text, boxes, confidence):
        """text: phrase or None (box-only); boxes: list of normalized [cx,cy,w,h]."""
        key = (text, tuple(map(tuple, boxes or [])), confidence)
        if key in self._cache:
            return self._cache[key]
        import torch
        import torch.nn.functional as F

        bo = self.state["backbone_out"]
        for k in ("language_features", "language_mask", "language_embeds"):
            bo.pop(k, None)
        bo.update(self.model.backbone.forward_text([text or "visual"], device=self.proc.device))
        gp = self.model._get_dummy_prompt()
        for b in boxes or []:
            gp.append_boxes(torch.tensor(b, device=self.proc.device, dtype=torch.float32).view(1, 1, 4),
                            torch.tensor([True], device=self.proc.device).view(1, 1))
        out = self.model.forward_grounding(backbone_out=bo, find_input=self.proc.find_stage,
                                           geometric_prompt=gp, find_target=None)

        presence = out["presence_logit_dec"].float().sigmoid()                 # (1, 1)
        probs = (out["pred_logits"].float().sigmoid() * presence.unsqueeze(1)).squeeze(-1)[0]
        keep = probs > confidence
        size = (self.h, self.w)
        if keep.any():
            m = F.interpolate(out["pred_masks"][0][keep].float().unsqueeze(1), size,
                              mode="bilinear", align_corners=False).sigmoid()[:, 0]
            inst_union = (m > 0.5).any(0)
            inst_prob = (m * probs[keep][:, None, None]).max(0).values
        else:
            inst_union = torch.zeros(size, dtype=torch.bool, device=presence.device)
            inst_prob = torch.zeros(size, device=presence.device)
        sem = F.interpolate(out["semantic_seg"][:1].float(), size, mode="bilinear",
                            align_corners=False).sigmoid()[0, 0]
        res = ClassMaps(
            inst_union=inst_union.cpu().numpy(),
            inst_prob=inst_prob.cpu().numpy().astype(np.float32),
            sem_prob=sem.cpu().numpy().astype(np.float32),
            presence=float(presence[0, 0]),
            n_inst=int(keep.sum()),
            max_score=float(probs.max()) if probs.numel() else 0.0,
        )
        self._cache[key] = res
        return res

    def road(self, cfg: Config, boxes=None):
        """Road mask + stats for one Config. Box modes fall back to text if no boxes."""
        mode = cfg.mode
        fallback = False
        if mode != "text" and not boxes:
            mode, fallback = "text", True
        if cfg.rule == "complement":
            pos = []
        elif mode == "box":
            pos = [self.class_maps(None, boxes, cfg.confidence)]
        else:
            b = boxes if mode == "text+box" else None
            pos = [self.class_maps(p, b, cfg.confidence) for p in cfg.prompts]
        neg = [self.class_maps(n, None, cfg.confidence) for n in cfg.negatives]
        mask = decide(cfg, pos, neg)
        ref = pos or neg
        stats = {"n_instances": sum(c.n_inst for c in ref),
                 "max_score": max(c.max_score for c in ref),
                 "presence": max(c.presence for c in ref),
                 "box_fallback_to_text": fallback, "n_boxes": len(boxes or [])}
        return mask, stats


def class_prob(c: ClassMaps, fusion):
    if fusion == "semantic":
        return c.sem_prob * c.presence
    return np.maximum(c.inst_prob, c.sem_prob) * c.presence      # fused


def decide(cfg: Config, pos, neg):
    """Combine per-class maps into a boolean road mask (pure numpy, testable)."""
    if cfg.rule == "complement":
        n = np.maximum.reduce([class_prob(c, cfg.fusion) for c in neg])
        return n <= cfg.prob_thd
    if cfg.fusion == "instance":
        return np.logical_or.reduce([c.inst_union for c in pos])
    p = np.maximum.reduce([class_prob(c, cfg.fusion) for c in pos])
    mask = p > cfg.prob_thd
    if neg:
        n = np.maximum.reduce([class_prob(c, cfg.fusion) for c in neg])
        mask &= p >= n
    return mask

"""Put the SAM 3 image checkpoint on the `cc-sam3-weights` volume and smoke-test it.

SAM 3 weights are gated on Hugging Face: request access at
https://huggingface.co/facebook/sam3, create a read token, then store it once:
  uv run modal secret create huggingface HF_TOKEN=hf_xxx

Usage (from ~/crosswalk/pipeline, MODAL_ENVIRONMENT=cook):
  uv run modal run cc_weights.py --action download
  uv run modal run cc_weights.py --action smoke-test
"""

import modal

from cc_common import (
    DEFAULT_CONFIDENCE, DEFAULT_PROMPT, HF_SECRET, SAM3_CKPT, SAM3_FILES, SAM3_REPO,
    WEIGHTS_VOLUME,
)
from cc_segment import sam3_image

app = modal.App("cc-crosswalk-weights")
weights = modal.Volume.from_name(WEIGHTS_VOLUME, create_if_missing=True)

dl_image = (
    modal.Image.debian_slim(python_version="3.12")
    .pip_install("huggingface_hub")
    .add_local_python_source("cc_common", "cc_segment")
)
smoke_image = sam3_image.add_local_python_source("cc_segment")


@app.function(image=dl_image, volumes={"/weights": weights}, timeout=3600,
              secrets=[modal.Secret.from_name(HF_SECRET)])
def download():
    import os

    from huggingface_hub import hf_hub_download

    dst = os.path.dirname(f"/weights/{SAM3_CKPT}")
    os.makedirs(dst, exist_ok=True)
    out = []
    for fn in SAM3_FILES:
        p = hf_hub_download(repo_id=SAM3_REPO, filename=fn, local_dir=dst,
                            token=os.environ["HF_TOKEN"])
        out.append(f"{p} ({os.path.getsize(p) / 1e6:.0f} MB)")
    weights.commit()
    return out


@app.function(image=smoke_image, gpu="L4", volumes={"/weights": weights}, timeout=1800)
def smoke_test(prompt: str = DEFAULT_PROMPT):
    import numpy as np
    import torch
    from PIL import Image
    from sam3.model.sam3_image_processor import Sam3Processor
    from sam3.model_builder import build_sam3_image_model

    model = build_sam3_image_model(checkpoint_path=f"/weights/{SAM3_CKPT}",
                                   load_from_HF=False, device="cuda")
    proc = Sam3Processor(model, confidence_threshold=DEFAULT_CONFIDENCE)
    # synthetic "intersection": grey cross of road on green ground
    img = np.full((1008, 1008, 3), (70, 120, 60), np.uint8)
    img[420:588, :] = img[:, 420:588] = (110, 110, 110)
    with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
        state = proc.set_image(Image.fromarray(img))
        out = proc.set_text_prompt(prompt=prompt, state=state)
    n = int(out["masks"].shape[0])
    return (f"OK: torch {torch.__version__}, GPU {torch.cuda.get_device_name(0)}, "
            f"prompt '{prompt}' -> {n} instance(s) on a synthetic test image")


@app.local_entrypoint()
def main(action: str = "download", prompt: str = DEFAULT_PROMPT):
    if action == "download":
        for line in download.remote():
            print(line)
    elif action == "smoke-test":
        print(smoke_test.remote(prompt))
    else:
        raise SystemExit("action must be 'download' or 'smoke-test'")

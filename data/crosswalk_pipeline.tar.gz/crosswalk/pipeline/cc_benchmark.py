"""Score SAM 3 road segmentation against the labelled curb dataset (Modal, GPU).

Runs every Config in a grid (cc_sam3.config_grid) on each benchmark image
(prepared by 04_bench_prep.py and uploaded to cc-results:/bench) and compares the
road mask with the ground-truth drivable mask:

  iou           road IoU
  bf1           boundary F1 at --tol-m (default 0.5 m): how well the predicted
                road edge follows the true curb, the quantity grow-cut cuts on
  bf1_prec/rec  its precision / recall
  bf1_1m        boundary F1 at 1.0 m
  area_ratio    predicted / true road area (below 1 = road under-called)

The 0.5 m tolerance assumes each image spans 50 m (the reference clip size).
That holds for coordinate-named Google clips; for Esri patches and screenshots
the true scale is unknown, so there it acts as a fixed pixel tolerance
(~10 px at 1024 px) and is comparable across configs, not in metres.

Outputs on cc-results:/bench_runs/<run-name>/: per_image.csv, summary.csv (one
row per Config, sorted by mean boundary F1), summary_by_source.csv, qa/<config>/*.jpg for the first
--qa-n images (road tint, predicted edge magenta, true curb green, boxes yellow).

Usage (from ~/crosswalk/pipeline, MODAL_ENVIRONMENT=cook):
  uv run modal run cc_benchmark.py --run-name zs1
  mkdir -p ../data/results/bench
  uv run modal volume get --env cook --force cc-results /bench_runs/zs1 ../data/results/bench/
  # -> ../data/results/bench/zs1/{summary.csv, summary_by_source.csv, per_image.csv, qa/}
"""

import modal

from cc_common import DEFAULT_CONFIDENCE, MIN_ROAD_PART_M2, RADIUS_M, RESULTS_VOLUME, SAM3_CKPT
from cc_segment import results, sam3_image, weights

app = modal.App("cc-crosswalk-benchmark")
bench_image = sam3_image.add_local_python_source("cc_segment")


def qa_overlay_gt(rgb, mask, gt, path, boxes=None, max_px=768):
    import cv2
    import numpy as np

    from cc_geom import cxcywh_to_pixels

    img = rgb.copy()
    img[mask] = (0.55 * img[mask] + 0.45 * np.array([0, 200, 255])).astype(np.uint8)
    img[cv2.Canny(gt.astype(np.uint8) * 255, 50, 150) > 0] = (0, 255, 0)
    img[cv2.Canny(mask.astype(np.uint8) * 255, 50, 150) > 0] = (255, 0, 255)
    h, w = img.shape[:2]
    for b in boxes or []:
        x0, y0, x1, y1 = cxcywh_to_pixels(b, w, h)
        cv2.rectangle(img, (x0, y0), (x1, y1), (255, 230, 0), max(2, w // 400))
    if max(h, w) > max_px:
        s = max_px / max(h, w)
        img = cv2.resize(img, (int(w * s), int(h * s)), interpolation=cv2.INTER_AREA)
    cv2.imwrite(path, cv2.cvtColor(img, cv2.COLOR_RGB2BGR), [cv2.IMWRITE_JPEG_QUALITY, 85])


@app.function(image=bench_image, gpu="L40S", timeout=6 * 3600,
              volumes={"/weights": weights, "/results": results})
def run(run_name: str, configs: list[dict], tol_m: float = 0.5, qa_n: int = 12,
        limit: int = 0, checkpoint: str = SAM3_CKPT, delta: str = "", subset: str = "all"):
    import json
    import os
    import time

    import numpy as np
    import pandas as pd
    import torch
    from PIL import Image

    from cc_geom import boundary_f1, fill_small_holes, iou
    from cc_sam3 import Config, ImageSession, load
    from cc_segment import drop_small_parts

    cfgs = [Config(**{**c, "prompts": tuple(c["prompts"]), "negatives": tuple(c["negatives"])})
            for c in configs]
    meta = json.load(open("/results/bench/meta.json"))
    if subset != "all":
        # holdout / val: originals listed in 05_make_holdout.py's split file
        keep = set(json.load(open("/results/bench/holdout.json"))[subset])
        meta = [m for m in meta if m.get("original") in keep]
        print(f"subset {subset}: {len(meta)} of {len(keep)} listed originals found")
    if limit:
        meta = meta[:limit]
    from collections import Counter
    print(f"benchmark set: {len(meta)} images; sources {dict(Counter(m.get('source', '?') for m in meta))}; "
          f"{sum(bool(m.get('boxes')) for m in meta)} with OSM boxes")
    out = f"/results/bench_runs/{run_name}"
    for c in cfgs:
        os.makedirs(f"{out}/qa/{c.key}", exist_ok=True)

    model, proc = load(f"/weights/{checkpoint}", delta=f"/weights/{delta}" if delta else None)
    model_label = delta or "zero-shot"
    rows = []
    t0 = time.time()
    for i, it in enumerate(meta):
        rgb = np.array(Image.open(f"/results/bench/images/{it['stem']}.jpg").convert("RGB"))
        gt = np.array(Image.open(f"/results/bench/gt/{it['stem']}.png")) > 127
        h, w = gt.shape
        m_per_px = 2 * RADIUS_M / w
        px_m2 = (2 * RADIUS_M / w) * (2 * RADIUS_M / h)
        boxes = it.get("boxes") or []
        with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
            sess = ImageSession(model, proc, rgb)
            for c in cfgs:
                mask, st = sess.road(c, boxes)
                mask = fill_small_holes(mask, px_m2, c.fill_holes_m2)
                mask = drop_small_parts(mask, px_m2, MIN_ROAD_PART_M2)
                prec, rec, f1 = boundary_f1(mask, gt, tol_m / m_per_px)
                _, _, f1_1m = boundary_f1(mask, gt, 1.0 / m_per_px)
                rows.append({"model": model_label, "stem": it["stem"], "source": it.get("source", "unknown"),
                             "split": it.get("split", ""), "config": c.key, "mode": c.mode,
                             "fusion": c.fusion, "prompts": "+".join(c.prompts),
                             "negatives": "+".join(c.negatives), "rule": c.rule,
                             "prob_thd": c.prob_thd, "fill_holes_m2": c.fill_holes_m2,
                             "iou": iou(mask, gt), "bf1": f1, "bf1_prec": prec, "bf1_rec": rec,
                             "bf1_1m": f1_1m,
                             "road_frac_pred": float(mask.mean()),
                             "road_frac_gt": float(gt.mean()), **st})
                if i < qa_n:
                    qa_overlay_gt(rgb, mask, gt, f"{out}/qa/{c.key}/{it['stem']}.jpg",
                                  boxes if c.mode != "text" else None)
        if (i + 1) % 10 == 0:
            print(f"  {i + 1}/{len(meta)}  ({(time.time() - t0) / (i + 1):.1f} s/image)")

    df = pd.DataFrame(rows)
    df.to_csv(f"{out}/per_image.csv", index=False)
    df["area_ratio"] = df["road_frac_pred"] / df["road_frac_gt"].where(df["road_frac_gt"] > 0)
    summ = (df.groupby(["config", "mode", "fusion", "prompts", "negatives", "rule",
                        "prob_thd", "fill_holes_m2"])
              .agg(n=("iou", "size"), iou_mean=("iou", "mean"), iou_median=("iou", "median"),
                   bf1_mean=("bf1", "mean"), bf1_median=("bf1", "median"),
                   bf1_prec=("bf1_prec", "mean"), bf1_rec=("bf1_rec", "mean"),
                   bf1_1m_mean=("bf1_1m", "mean"),
                   area_ratio_median=("area_ratio", "median"),
                   box_fallback=("box_fallback_to_text", "mean"))
              .sort_values("bf1_mean", ascending=False).reset_index())
    summ.to_csv(f"{out}/summary.csv", index=False)
    # same ranking broken down by image source (Google clips vs Esri patches vs
    # screenshots) and by whether OSM boxes were available for the image
    df["has_boxes"] = df["n_boxes"] > 0
    (df.groupby(["config", "source", "has_boxes"])
       .agg(n=("iou", "size"), iou_mean=("iou", "mean"), bf1_mean=("bf1", "mean"),
            bf1_1m_mean=("bf1_1m", "mean"), area_ratio_median=("area_ratio", "median"))
       .reset_index().sort_values(["source", "has_boxes", "bf1_mean"], ascending=[True, True, False])
       .to_csv(f"{out}/summary_by_source.csv", index=False))
    with open(f"{out}/run.json", "w") as f:
        json.dump({"configs": configs, "tol_m": tol_m, "n_images": len(meta),
                   "checkpoint": checkpoint, "delta": delta, "subset": subset}, f, indent=2)
    results.commit()
    return summ.head(10).to_string(index=False)


@app.local_entrypoint()
def main(run_name: str, modes: str = "text,box,text+box", fusions: str = "instance,semantic,fused",
         prompt_sets: str = "road;street;roadway;asphalt road",
         negative_sets: str = ";sidewalk,grass,building",
         prob_thd: float = 0.3, confidence: float = DEFAULT_CONFIDENCE,
         tol_m: float = 0.5, qa_n: int = 12, limit: int = 0,
         prob_thds: str = "", fill_holes: str = "0", rules: str = "positive",
         delta: str = "", subset: str = "all"):
    """Grid = modes x fusions x prompt sets x negative sets x thresholds x hole
    fills x rules. ';' separates sets, ',' separates items. Example (round 2):
      --modes text --fusions fused --prompt-sets "road;road,car,crosswalk"
      --negative-sets ";sidewalk,grass,building,tree" --prob-thds 0.3,0.2,0.15
      --fill-holes 0,10,25 --rules positive,complement
    --delta finetuned/<run>/seg_head_best.pt  loads a cc_finetune.py head (path in cc-sam3-weights)
    --subset holdout|val                      scores only those originals (needs /bench/holdout.json)"""
    from dataclasses import asdict

    from cc_sam3 import config_grid

    def split(s, sep=","):
        return [x.strip() for x in s.split(sep) if x.strip()]

    cfgs = config_grid(split(modes), split(fusions),
                       [split(s) for s in prompt_sets.split(";") if s.strip()],
                       [split(s) for s in negative_sets.split(";")],
                       prob_thd, confidence,
                       prob_thds=[float(x) for x in split(prob_thds)] or None,
                       fill_holes=[float(x) for x in split(fill_holes)] or [0.0],
                       rules=split(rules))
    print(f"benchmarking {len(cfgs)} configs")
    if subset not in ("all", "holdout", "val"):
        raise SystemExit("--subset must be all, holdout or val")
    print(run.remote(run_name, [asdict(c) for c in cfgs], tol_m=tol_m, qa_n=qa_n, limit=limit,
                     delta=delta, subset=subset))
    print(f"full results: volume {RESULTS_VOLUME}:/bench_runs/{run_name}")

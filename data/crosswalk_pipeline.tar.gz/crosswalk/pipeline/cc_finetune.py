"""Fine-tune SAM 3's segmentation head for the drivable surface (Modal, GPU).

What is trained
  Only `segmentation_head` (pixel decoder, prompt cross-attention, semantic and
  instance heads; a few million parameters). The image encoder, text encoder,
  fusion encoder and detector decoder stay frozen. The head learns to turn
  SAM 3's existing features for the prompt "road" into the labels' notion of
  drivable surface: curb to curb, parked cars and crosswalk paint included.

Objective
  The semantic logits for the text prompt are compared with the ground-truth
  drivable mask (everything not labelled non-drivable) using
    BCE (pixels within ~1 m of a true curb weighted up to x(1 + curb_weight))
    + soft Dice,
  at 504 x 504. Augmentation: random 90-degree rotation, flips, mild colour jitter
  (the training set also contains Roboflow's own augmented copies).

Data (prepared on the server)
  cc-results:/train_full   04_bench_prep.py --keep-duplicates --no-osm output
  cc-results:/bench/holdout.json   05_make_holdout.py split by original name
  Holdout originals are never trained on; `val` originals pick the best epoch.

Output
  cc-sam3-weights:/finetuned/<run>/seg_head_best.pt and seg_head_last.pt
     ({"segmentation_head": state_dict, "meta": {...}}); load with
     cc_sam3.load(..., delta="finetuned/<run>/seg_head_best.pt")
  cc-results:/finetune_runs/<run>/log.csv, run.json

Usage (from ~/crosswalk/pipeline, MODAL_ENVIRONMENT=cook):
  uv run modal run cc_finetune.py --run-name ft1 --epochs 12
  uv run modal run cc_finetune.py --run-name smoke --epochs 1 --max-steps 20   # plumbing test
"""

import modal

from cc_common import MIN_ROAD_PART_M2, RADIUS_M, RESULTS_VOLUME, SAM3_CKPT, WEIGHTS_VOLUME
from cc_segment import results, sam3_image, weights

app = modal.App("cc-crosswalk-finetune")
ft_image = sam3_image.add_local_python_source("cc_segment")

TRAIN_RES = 504          # loss resolution (pixels per side); clips span 50 m -> ~10 cm/px


# ------------------------------------------------------------------ pure helpers
def curb_weight_map(gt, m_per_px, sigma_m=0.5, weight=4.0):
    """1 + weight * exp(-d / sigma) where d = distance (m) to the nearest true curb."""
    import numpy as np
    from scipy import ndimage

    m = gt.astype(bool)
    edge = m ^ ndimage.binary_erosion(m, structure=np.ones((3, 3), bool), border_value=1)
    edge[0, :] = edge[-1, :] = edge[:, 0] = edge[:, -1] = False       # frame is not a curb
    if not edge.any():
        return np.ones(m.shape, np.float32)
    d = ndimage.distance_transform_edt(~edge) * m_per_px
    return (1.0 + weight * np.exp(-d / sigma_m)).astype(np.float32)


def augment(rgb, gt, rng):
    """Random 90-degree rotation, flips and mild brightness/contrast/saturation jitter."""
    import numpy as np

    k = int(rng.integers(4))
    rgb, gt = np.rot90(rgb, k), np.rot90(gt, k)
    if rng.random() < 0.5:
        rgb, gt = rgb[:, ::-1], gt[:, ::-1]
    if rng.random() < 0.5:
        rgb, gt = rgb[::-1], gt[::-1]
    x = rgb.astype(np.float32)
    x = (x - x.mean()) * rng.uniform(0.85, 1.15) + x.mean() * rng.uniform(0.9, 1.1)
    grey = x.mean(axis=2, keepdims=True)
    x = grey + (x - grey) * rng.uniform(0.85, 1.15)
    return np.clip(x, 0, 255).astype(np.uint8).copy(), gt.copy()


def split_items(meta, split):
    """Training items exclude every copy of a holdout or val original."""
    held = set(split["holdout"]) | set(split["val"])
    train = [m for m in meta if m["original"] not in held]
    val = [m for m in meta if m["original"] in set(split["val"])]
    # one copy per val original (prefer test/valid split copies)
    order = {"test": 0, "valid": 1, "train": 2}
    seen, val_one = set(), []
    for m in sorted(val, key=lambda m: order.get(m.get("split"), 3)):
        if m["original"] not in seen:
            seen.add(m["original"])
            val_one.append(m)
    return train, val_one


# --------------------------------------------------------------------- training
@app.function(image=ft_image, gpu="L40S", timeout=8 * 3600,
              volumes={"/weights": weights, "/results": results})
def train(run_name: str, prompt: str = "road", epochs: int = 12, lr: float = 1e-4,
          weight_decay: float = 1e-4, accum: int = 4, curb_weight: float = 4.0,
          val_thd: float = 0.4, val_fill_m2: float = 25.0, max_steps: int = 0,
          seed: int = 0, checkpoint: str = SAM3_CKPT):
    import csv
    import json
    import math
    import os
    import time

    import numpy as np
    import torch
    import torch.nn.functional as F
    from PIL import Image
    from torchvision.transforms import v2

    from cc_geom import boundary_f1, fill_small_holes, iou
    from cc_sam3 import Config, ImageSession, load
    from cc_segment import drop_small_parts

    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)
    meta = json.load(open("/results/train_full/meta.json"))
    split = json.load(open("/results/bench/holdout.json"))
    train_items, val_items = split_items(meta, split)
    print(f"train {len(train_items)} images ({len({m['original'] for m in train_items})} originals); "
          f"val {len(val_items)}; holdout {len(split['holdout'])} originals excluded")

    model, proc = load(f"/weights/{checkpoint}")
    model.eval()
    for p in model.parameters():
        p.requires_grad_(False)
    head = model.segmentation_head
    for p in head.parameters():
        p.requires_grad_(True)
    n_par = sum(p.numel() for p in head.parameters())
    print(f"training segmentation_head: {n_par / 1e6:.2f} M parameters")

    opt = torch.optim.AdamW([p for p in head.parameters() if p.requires_grad],
                            lr=lr, weight_decay=weight_decay)
    total = epochs * math.ceil(len(train_items) / accum)
    if max_steps:
        total = min(total, max(1, max_steps // accum))
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=lr, total_steps=max(total, 2),
                                                pct_start=0.1, anneal_strategy="cos")

    device = proc.device
    with torch.no_grad():
        text_out = model.backbone.forward_text([prompt], device=device)

    def load_item(m):
        rgb = np.array(Image.open(f"/results/train_full/images/{m['stem']}.jpg").convert("RGB"))
        gt = np.array(Image.open(f"/results/train_full/gt/{m['stem']}.png")) > 127
        return rgb, gt

    def forward_semantic(rgb):
        """Semantic logits (1, 1, h, w) for the prompt; grads flow only into the head."""
        with torch.no_grad():
            img = proc.transform(v2.functional.to_image(Image.fromarray(rgb)).to(device)).unsqueeze(0)
            bo = model.backbone.forward_image(img)
            bo.update({k: v for k, v in text_out.items()})
        out = model.forward_grounding(backbone_out=bo, find_input=proc.find_stage,
                                      geometric_prompt=model._get_dummy_prompt(), find_target=None)
        return out["semantic_seg"][:1].float()

    def evaluate():
        model.eval()
        cfg = Config(mode="text", fusion="semantic", prompts=(prompt,), prob_thd=val_thd,
                     fill_holes_m2=val_fill_m2)
        scores = []
        for m in val_items:
            rgb, gt = load_item(m)
            h, w = gt.shape
            m_per_px, px_m2 = 2 * RADIUS_M / w, (2 * RADIUS_M / w) * (2 * RADIUS_M / h)
            with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
                mask, _ = ImageSession(model, proc, rgb).road(cfg)
            mask = drop_small_parts(fill_small_holes(mask, px_m2, cfg.fill_holes_m2), px_m2, MIN_ROAD_PART_M2)
            scores.append((iou(mask, gt), boundary_f1(mask, gt, 0.5 / m_per_px)[2],
                           boundary_f1(mask, gt, 1.0 / m_per_px)[2]))
        s = np.array(scores) if scores else np.zeros((1, 3))
        return {"val_iou": float(s[:, 0].mean()), "val_bf1": float(s[:, 1].mean()),
                "val_bf1_1m": float(s[:, 2].mean())}

    wdir = f"/weights/finetuned/{run_name}"
    rdir = f"/results/finetune_runs/{run_name}"
    os.makedirs(wdir, exist_ok=True)
    os.makedirs(rdir, exist_ok=True)
    log = []
    base = evaluate()
    print(f"epoch 0 (zero-shot head): {base}")
    log.append({"epoch": 0, "loss": None, **base})
    best = base["val_bf1"]

    def save(path, ep, metrics):
        torch.save({"segmentation_head": {k: v.detach().cpu() for k, v in head.state_dict().items()},
                    "meta": {"run": run_name, "epoch": ep, "prompt": prompt, "metrics": metrics,
                             "base_checkpoint": checkpoint}}, path)

    step, t0 = 0, time.time()
    for ep in range(1, epochs + 1):
        order = rng.permutation(len(train_items))
        losses = []
        opt.zero_grad(set_to_none=True)
        for i, idx in enumerate(order):
            rgb, gt = load_item(train_items[idx])
            rgb, gt = augment(rgb, gt, rng)
            m_per_px_train = 2 * RADIUS_M / TRAIN_RES
            gt_r = np.array(Image.fromarray(gt.astype(np.uint8) * 255).resize(
                (TRAIN_RES, TRAIN_RES), Image.NEAREST)) > 127
            wmap = curb_weight_map(gt_r, m_per_px_train, weight=curb_weight)
            target = torch.from_numpy(gt_r.astype(np.float32))[None, None].to(device)
            weight = torch.from_numpy(wmap)[None, None].to(device)

            with torch.autocast("cuda", dtype=torch.bfloat16):
                logits = forward_semantic(rgb)
            logits = F.interpolate(logits, (TRAIN_RES, TRAIN_RES), mode="bilinear", align_corners=False)
            bce = (F.binary_cross_entropy_with_logits(logits, target, reduction="none") * weight).sum() / weight.sum()
            prob = logits.sigmoid()
            dice = 1 - (2 * (prob * target).sum() + 1) / (prob.sum() + target.sum() + 1)
            loss = (bce + dice) / accum
            loss.backward()
            losses.append(float(loss) * accum)
            if (i + 1) % accum == 0 or i == len(order) - 1:
                torch.nn.utils.clip_grad_norm_(head.parameters(), 1.0)
                opt.step()
                opt.zero_grad(set_to_none=True)
                if step < sched.total_steps - 1:
                    sched.step()
                step += 1
            if max_steps and (i + 1) >= max_steps:
                break
            if (i + 1) % 50 == 0:
                print(f"  epoch {ep} {i + 1}/{len(order)}  loss {np.mean(losses[-50:]):.4f}  "
                      f"({(time.time() - t0) / 60:.1f} min)")
        metrics = evaluate()
        row = {"epoch": ep, "loss": float(np.mean(losses)), **metrics}
        log.append(row)
        print(f"epoch {ep}: {row}")
        save(f"{wdir}/seg_head_last.pt", ep, metrics)
        if metrics["val_bf1"] > best:
            best = metrics["val_bf1"]
            save(f"{wdir}/seg_head_best.pt", ep, metrics)
            print(f"  new best val_bf1 {best:.3f} -> {wdir}/seg_head_best.pt")
        weights.commit()
        if max_steps:
            break

    if not os.path.exists(f"{wdir}/seg_head_best.pt"):     # never beat zero-shot: keep last
        save(f"{wdir}/seg_head_best.pt", ep, log[-1])
    with open(f"{rdir}/log.csv", "w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=list(log[0].keys()))
        wr.writeheader()
        wr.writerows(log)
    with open(f"{rdir}/run.json", "w") as f:
        json.dump({"prompt": prompt, "epochs": epochs, "lr": lr, "weight_decay": weight_decay,
                   "accum": accum, "curb_weight": curb_weight, "val_thd": val_thd,
                   "val_fill_m2": val_fill_m2, "train_res": TRAIN_RES, "seed": seed,
                   "n_train": len(train_items), "n_val": len(val_items),
                   "n_head_params": n_par, "best_val_bf1": best}, f, indent=2)
    weights.commit()
    results.commit()
    return "\n".join(f"epoch {r['epoch']:>2}: loss {r['loss'] if r['loss'] is None else round(r['loss'], 4)}  "
                     f"val IoU {r['val_iou']:.3f}  val bf1 {r['val_bf1']:.3f}  val bf1@1m {r['val_bf1_1m']:.3f}"
                     for r in log)


@app.local_entrypoint()
def main(run_name: str, prompt: str = "road", epochs: int = 12, lr: float = 1e-4,
         accum: int = 4, curb_weight: float = 4.0, max_steps: int = 0, seed: int = 0,
         gpu: str = "L40S"):
    fn = train.with_options(gpu=gpu) if gpu != "L40S" else train
    print(fn.remote(run_name, prompt=prompt, epochs=epochs, lr=lr, accum=accum,
                    curb_weight=curb_weight, max_steps=max_steps, seed=seed))
    print(f"weights: volume {WEIGHTS_VOLUME}:/finetuned/{run_name}/seg_head_best.pt")
    print(f"log:     volume {RESULTS_VOLUME}:/finetune_runs/{run_name}/log.csv")

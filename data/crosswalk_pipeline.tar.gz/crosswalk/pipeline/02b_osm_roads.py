"""Download OSM drivable road centre-lines around clips, for SAM 3 box prompts (local).

Points are grouped into ~2 km cells and each cell is one Overpass query, so a
county-wide sample or a multi-city benchmark is a few dozen requests.

Usage:
  uv run python 02b_osm_roads.py --inputs ../data/sample/sample.csv,../data/sample/pilot.csv \
      --out ../data/sample/osm_roads.geojson
  uv run modal volume put --env cook cc-results ../data/sample/osm_roads.geojson /inputs/osm_roads.geojson
"""

import argparse
import time

import geopandas as gpd
import pandas as pd
from shapely.geometry import box

from cc_common import bbox_lonlat

DRIVABLE = ["motorway_link", "trunk", "trunk_link", "primary", "primary_link",
            "secondary", "secondary_link", "tertiary", "tertiary_link",
            "unclassified", "residential", "living_street", "busway"]


def fetch_drivable_lines(lats, lons, radius_m=40.0, cell_deg=0.02, retries=3):
    """Drivable centre-lines (EPSG:4326) covering a radius_m square around each point."""
    import osmnx as ox

    ox.settings.requests_timeout = 300
    df = pd.DataFrame({"lat": lats, "lon": lons})
    df["cell"] = list(zip((df.lat / cell_deg).round().astype(int),
                          (df.lon / cell_deg).round().astype(int)))
    parts = []
    cells = df.groupby("cell")
    for i, (_, g) in enumerate(cells):
        area = gpd.GeoSeries([box(*bbox_lonlat(la, lo, radius=radius_m))
                              for la, lo in zip(g.lat, g.lon)], crs=4326).union_all()
        for attempt in range(retries):
            try:
                f = ox.features_from_polygon(area, tags={"highway": DRIVABLE})
                break
            except Exception as e:                       # noqa: BLE001
                if "No matching features" in str(e) or "InsufficientResponse" in type(e).__name__:
                    f = None
                    break
                if attempt == retries - 1:
                    print(f"  cell {i + 1}/{cells.ngroups}: giving up ({e})")
                    f = None
                time.sleep(5 * (attempt + 1))
        if f is not None and len(f):
            f = f[f.geom_type.isin(["LineString", "MultiLineString"])]
            if "access" in f:
                f = f[~f["access"].isin(["private", "no"])]
            parts.append(f[["highway", "geometry"]].reset_index(drop=True))
        print(f"  cell {i + 1}/{cells.ngroups}: {0 if f is None else len(f)} lines")
    if not parts:
        return gpd.GeoDataFrame({"highway": []}, geometry=[], crs=4326)
    out = pd.concat(parts, ignore_index=True)
    out = out[~out.geometry.duplicated()]
    return gpd.GeoDataFrame(out, geometry="geometry", crs=4326)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--inputs", required=True, help="comma-separated CSVs with lat, lon columns")
    p.add_argument("--out", required=True)
    a = p.parse_args()
    df = pd.concat([pd.read_csv(f.strip()) for f in a.inputs.split(",")], ignore_index=True)
    df = df.drop_duplicates(["lat", "lon"])
    roads = fetch_drivable_lines(df.lat.tolist(), df.lon.tolist())
    roads.to_file(a.out, driver="GeoJSON")
    print(f"wrote {len(roads)} road lines for {len(df)} clips -> {a.out}")


if __name__ == "__main__":
    main()

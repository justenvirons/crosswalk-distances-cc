"""Prepare the SAM 3 benchmark from the public "Satellite Curb Segmentation"
dataset (Roboflow Universe, pcd-rxiqe, CC BY 4.0) (local).

The dataset is hand-labelled Google satellite clips of US intersections with one
class, non-drivable (sidewalks, buildings, parks, refuge islands); everything
unlabelled is roadway. For each image this script writes:

  images/<stem>.jpg   the clip
  gt/<stem>.png       ground-truth drivable mask (255 = road)
  meta.json           size, centre lat/lon (parsed from the file name) and SAM 3
                      exemplar boxes on OSM road centre-lines

All splits are used by default. Roboflow stores several augmented copies of each
training image (flips, rotations, blur, noise; named <original>.rf.<hash>.jpg), so
images are de-duplicated on the original name, keeping the test/valid copy where
one exists. Flips and rotations do not affect text-prompt scoring, but they would
misalign OSM boxes, so boxes are only placed on test/valid copies. Images whose
file names carry no coordinates (e.g. Esri patches, screenshots) get no boxes and
are scored with text prompts only.

Usage (uses YOUR Roboflow API key, from a free account):
  export ROBOFLOW_API_KEY=xxxx
  uv run python 04_bench_prep.py --list-versions          # find the right version first
  (version 15 = the reference study's 193 training images, augmented x3, + 15 test)
For OSM boxes on every coordinate-named clip, fork the dataset into your own
workspace, generate a version WITHOUT augmentation, and pass
  --workspace <your-workspace> --project <your-project-slug> --version <N>
  uv run python 04_bench_prep.py --version 6 --out ../data/bench
  uv run modal volume put --env cook cc-results ../data/bench /bench
Offline / already downloaded COCO export:
  uv run python 04_bench_prep.py --coco-dir path/to/export --out ../data/bench
"""

import argparse
import json
import os
import re
import shutil
import tempfile

import numpy as np
from PIL import Image, ImageDraw

from cc_common import RADIUS_M, bbox_lonlat

WORKSPACE, PROJECT = "pcd-rxiqe", "satellite-curb-segmentation"
COORD_RE = re.compile(r"(\d{6,})([NS])_(\d{6,})([EW])")


def parse_latlon(name, precision=6):
    m = COORD_RE.search(name)
    if not m:
        return None
    lat = int(m.group(1)) / 10**precision * (1 if m.group(2) == "N" else -1)
    lon = int(m.group(3)) / 10**precision * (1 if m.group(4) == "E" else -1)
    return lat, lon


def original_name(file_name):
    """'boston_patch_2_esri_png.rf.52d0….jpg' -> 'boston_patch_2_esri_png'."""
    return re.split(r"\.rf\.", file_name)[0] if ".rf." in file_name else os.path.splitext(file_name)[0]


def source_kind(name):
    n = name.lower()
    if COORD_RE.search(name):
        return "coords-in-name"
    for k in ("esri", "google", "screenshot", "mapbox", "bing", "naip"):
        if k in n:
            return k
    return "other"


def nondrivable_mask(anns, width, height):
    """Rasterize COCO polygon annotations (all = non-drivable) to a bool mask."""
    img = Image.new("L", (width, height), 0)
    d = ImageDraw.Draw(img)
    skipped = 0
    for a in anns:
        seg = a.get("segmentation")
        if isinstance(seg, list) and seg:
            for poly in seg:
                if len(poly) >= 6:
                    d.polygon(list(zip(poly[0::2], poly[1::2])), fill=1)
        else:
            skipped += 1                      # RLE or empty: not expected from Roboflow polygons
    return np.array(img, bool), skipped


def _project():
    from roboflow import Roboflow

    key = os.environ.get("ROBOFLOW_API_KEY")
    if not key:
        raise SystemExit("Set ROBOFLOW_API_KEY to your own Roboflow API key")
    return Roboflow(api_key=key).workspace(WORKSPACE).project(PROJECT)


def _set_project(workspace, project):
    global WORKSPACE, PROJECT
    WORKSPACE, PROJECT = workspace, project


def list_versions():
    """Print every dataset version's size, splits, date and augmentation, to find
    the version holding the reference study's coordinate-named Google clips."""
    import datetime

    rows = []
    for v in _project().get_version_information():
        vid = str(v.get("id", "")).rsplit("/", 1)[-1]
        created = v.get("created")
        try:
            created = datetime.datetime.fromtimestamp(float(created) / (1000 if float(created) > 1e11 else 1)).date()
        except (TypeError, ValueError):
            pass
        aug = v.get("augmentation") or {}
        rows.append((int(vid) if vid.isdigit() else vid, v.get("name", ""), created, v.get("images"),
                     v.get("splits") or {}, ", ".join(sorted(k for k, val in aug.items() if val)) or "none"))
    print(f"{'ver':>4}  {'created':10}  {'images':>6}  {'train/valid/test':>16}  augmentation")
    for vid, name, created, n, sp, aug in sorted(rows, key=lambda r: (str(type(r[0])), r[0])):
        tvt = f"{sp.get('train', '?')}/{sp.get('valid', '?')}/{sp.get('test', '?')}"
        print(f"{vid!s:>4}  {created!s:10}  {n!s:>6}  {tvt:>16}  {aug}")
    print("\nThe reference study used 193 source images (augmented to 5,790). Prefer the version "
          "whose image count fits that, then run this script with --version N and check the "
          "source table for 'coords-in-name'.")


def download(version, dest):
    ds = _project().version(version).download(
        "coco-segmentation", location=dest, overwrite=True)
    return ds.location


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--version", type=int, default=6)
    p.add_argument("--coco-dir", default="", help="use an existing COCO export instead of downloading")
    p.add_argument("--splits", default="test,valid,train",
                   help="order matters: the first copy of each original image is kept")
    p.add_argument("--keep-duplicates", action="store_true")
    p.add_argument("--out", default="")
    p.add_argument("--workspace", default=WORKSPACE,
                   help="Roboflow workspace (your own, if you forked the dataset)")
    p.add_argument("--project", default=PROJECT)
    p.add_argument("--list-versions", action="store_true",
                   help="print every dataset version's size and splits, then exit")
    p.add_argument("--no-osm", action="store_true", help="skip OSM boxes (text-only benchmark)")
    a = p.parse_args()
    _set_project(a.workspace, a.project)
    if a.list_versions:
        return list_versions()
    if not a.out:
        p.error("--out is required unless --list-versions")

    src = a.coco_dir or download(a.version, tempfile.mkdtemp(prefix="curb_"))
    os.makedirs(os.path.join(a.out, "images"), exist_ok=True)
    os.makedirs(os.path.join(a.out, "gt"), exist_ok=True)

    items, seen, n_dup = [], set(), 0
    for split in [s.strip() for s in a.splits.split(",") if s.strip()]:
        jf = os.path.join(src, split, "_annotations.coco.json")
        if not os.path.exists(jf):
            print(f"no {split} split in {src}; skipping")
            continue
        coco = json.load(open(jf))
        by_img = {}
        for ann in coco["annotations"]:
            by_img.setdefault(ann["image_id"], []).append(ann)
        for im in coco["images"]:
            base = original_name(im["file_name"])
            if not a.keep_duplicates and base in seen:
                n_dup += 1
                continue
            seen.add(base)
            stem = f"{split}_{os.path.splitext(im['file_name'])[0]}"
            nd, skipped = nondrivable_mask(by_img.get(im["id"], []), im["width"], im["height"])
            Image.fromarray((~nd).astype(np.uint8) * 255).save(os.path.join(a.out, "gt", stem + ".png"))
            Image.open(os.path.join(src, split, im["file_name"])).convert("RGB").save(
                os.path.join(a.out, "images", stem + ".jpg"), quality=95)
            ll = parse_latlon(im["file_name"]) if split != "train" else None
            items.append({"stem": stem, "split": split, "file_name": im["file_name"],
                          "original": base, "source": source_kind(base),
                          "width": im["width"], "height": im["height"],
                          "lat": ll[0] if ll else None, "lon": ll[1] if ll else None,
                          "road_frac_gt": float((~nd).mean()), "rle_skipped": skipped,
                          "boxes": []})
    print(f"{len(items)} unique images ({n_dup} augmented duplicates dropped); "
          f"{sum(i['lat'] is not None for i in items)} usable for OSM boxes")
    by = {}
    for i in items:
        by.setdefault((i["split"], i["source"]), []).append(i["original"])
    for (sp, src_kind), names in sorted(by.items()):
        print(f"  {sp:5s} {src_kind:22s} {len(names):4d}   e.g. {names[0]}")

    if not a.no_osm:
        add_osm_boxes(items)
    with open(os.path.join(a.out, "meta.json"), "w") as f:
        json.dump(items, f, indent=1)
    if not a.coco_dir:
        shutil.rmtree(src, ignore_errors=True)
    nb = [len(i["boxes"]) for i in items]
    print(f"boxes per image: mean {np.mean(nb):.1f}, none for {sum(n == 0 for n in nb)} images")
    print(f"wrote {a.out}/meta.json, images/, gt/")


def add_osm_boxes(items):
    from importlib import import_module

    import geopandas as gpd
    from shapely.geometry import Point
    from shapely.geometry import box as sbox

    from cc_geom import boxes_to_cxcywh, centerline_boxes, mercator_units_per_m

    geo = [i for i in items if i["lat"] is not None]
    if not geo:
        return
    fetch = import_module("02b_osm_roads").fetch_drivable_lines
    roads = fetch([i["lat"] for i in geo], [i["lon"] for i in geo]).to_crs(3857)
    sidx = roads.sindex
    for it in geo:
        w, s, e, n = bbox_lonlat(it["lat"], it["lon"], radius=RADIUS_M)
        b = gpd.GeoSeries.from_xy([w, e], [s, n], crs=4326).to_crs(3857)
        bounds = (b.x.min(), b.y.min(), b.x.max(), b.y.max())
        frame = sbox(*bounds)
        lines = []
        for g in roads.geometry.iloc[sidx.query(frame)]:
            x = g.intersection(frame)
            if not x.is_empty:
                lines.extend(getattr(x, "geoms", [x]))
        lines = [ln for ln in lines if ln.geom_type == "LineString"]
        center = Point((bounds[0] + bounds[2]) / 2, (bounds[1] + bounds[3]) / 2)
        bx = centerline_boxes(lines, center, mercator_units_per_m(it["lat"]), bounds=bounds)
        it["boxes"] = boxes_to_cxcywh(bx, bounds)


if __name__ == "__main__":
    main()

"""Split the curb dataset by ORIGINAL image into holdout / validation / training (local).

  holdout  scored only by cc_benchmark.py (--subset holdout), never seen in training.
           Coordinate-named Google clips only (the imagery most like candidate A):
           every test-split clip first, then random training originals.
  val      used by cc_finetune.py to pick the best epoch; never trained on, and kept
           separate from holdout so the final score is not tuned on its own test set.
  train    everything else, including all of Roboflow's augmented copies.

Splitting by original name matters: Roboflow stores ~3 augmented copies of every
training image, and a copy of a holdout image in training would leak its labels.

Usage:
  uv run python 05_make_holdout.py --meta ../data/bench/meta.json \
      --n-holdout 40 --n-val 15 --out ../data/bench/holdout.json
  uv run modal volume put --env cook --force cc-results ../data/bench/holdout.json /bench/holdout.json
"""

import argparse
import json
import random


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--meta", required=True, help="de-duplicated benchmark meta.json (04_bench_prep.py)")
    p.add_argument("--n-holdout", type=int, default=40)
    p.add_argument("--n-val", type=int, default=15)
    p.add_argument("--seed", type=int, default=2026)
    p.add_argument("--out", required=True)
    a = p.parse_args()

    meta = json.load(open(a.meta))
    if not all("original" in m for m in meta):
        raise SystemExit("meta.json lacks 'original' names; re-run 04_bench_prep.py with the current version")
    rng = random.Random(a.seed)

    google = [m for m in meta if m.get("source") == "coords-in-name"]
    test_first = sorted({m["original"] for m in google if m["split"] == "test"})
    rest = sorted({m["original"] for m in google if m["split"] != "test"} - set(test_first))
    rng.shuffle(rest)
    holdout = (test_first + rest)[:a.n_holdout]

    remaining = sorted({m["original"] for m in meta} - set(holdout))
    rng.shuffle(remaining)
    val = remaining[:a.n_val]
    train = sorted(set(remaining) - set(val))

    out = {"seed": a.seed, "holdout": sorted(holdout), "val": sorted(val), "train": train}
    with open(a.out, "w") as f:
        json.dump(out, f, indent=1)
    print(f"holdout {len(holdout)} (Google clips; {len(test_first)} from the test split) | "
          f"val {len(val)} | train {len(train)} originals -> {a.out}")


if __name__ == "__main__":
    main()

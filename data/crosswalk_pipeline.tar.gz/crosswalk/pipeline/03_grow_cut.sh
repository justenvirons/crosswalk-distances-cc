#!/usr/bin/env bash
# Measure crossings: run the reference repo's grow-cut, unchanged, on one SAM 3
# segmentation run, then copy the refined crossings into ~/crosswalk/data/results.
#
# Usage:  ./03_grow_cut.sh A v1        (candidate letter, run name used in cc_segment.py)
set -euo pipefail

CAND="$1"              # A (Google) | B (Cook County RGB)
RUN="$2"               # e.g. v1
ROOT="$HOME/crosswalk"
REF="$ROOT/pipeline/crossing-distances"
case "$CAND" in
  A) SUB=A_google ;;
  B) SUB=B_cook_rgb ;;
  *) echo "candidate must be A or B"; exit 1 ;;
esac

OUT="$ROOT/data/results/$SUB/$RUN"
mkdir -p "$OUT" "$ROOT/logs"

# 1. pull the drivable-surface polygons from Modal
cd "$ROOT/pipeline"
uv run modal volume get --env cook --force cc-results "/$SUB/$RUN/cross_walks.geojson" "$OUT/"
uv run modal volume get --env cook --force cc-results "/$SUB/$RUN/segment_stats.csv" "$OUT/"

# 2. stage inputs where the reference grow_cut looks for them when run locally:
#    ./data/<MODAL_ENVIRONMENT>_crossings/{cross_walks.geojson,crosswalk_edges_v2_0.shp}
STAGE="$REF/data/cook_crossings"
rm -rf "$STAGE" && mkdir -p "$STAGE"
cp "$OUT/cross_walks.geojson" "$STAGE/"
cp "$ROOT"/data/osm/crosswalk_edges_v2_0.* "$STAGE/"

# 3. run grow-cut locally (modal.is_local() == True -> local file paths)
cd "$REF"
MODAL_ENVIRONMENT=cook uv run python -m inference.grow_cut 2>&1 | tee "$ROOT/logs/grow_cut_${SUB}_${RUN}.log"

# 4. collect outputs
cp "$STAGE"/refined_crosswalks_v3_0_4.* "$OUT/"
echo "refined crossings -> $OUT"

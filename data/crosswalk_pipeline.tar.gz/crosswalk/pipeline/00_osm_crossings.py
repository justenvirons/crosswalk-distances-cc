"""Step 0 (local, CPU): build OSM crossing edges for Cook County with the
reference repo's own code (inference/osm_ingest.py::osm_ingest_local).

Run from the reference repo's environment, e.g.:
  cd ~/crosswalk/pipeline/crossing-distances
  MODAL_ENVIRONMENT=cook nohup uv run python ../00_osm_crossings.py \
      --place "Cook County, Illinois, USA" --out ~/crosswalk/data/osm \
      > ~/crosswalk/logs/osm_ingest.log 2>&1 &

Writes crosswalk_edges_v2_0.shp, intersection_coordinates_v2_0.csv and
raw_intersection_coordinates_v2_0.csv to --out.
"""

import argparse
import os
import sys

sys.path.insert(0, os.getcwd())  # so `inference` resolves to the reference repo

import osmnx as ox  # noqa: E402

from inference.osm_ingest import osm_ingest_local  # noqa: E402

p = argparse.ArgumentParser()
p.add_argument("--place", required=True)
p.add_argument("--out", required=True)
p.add_argument("--overpass-url", default=None,
               help="optional Overpass mirror, e.g. https://overpass.kumi.systems/api")
a = p.parse_args()

os.makedirs(os.path.expanduser(a.out), exist_ok=True)
ox.settings.requests_timeout = 900
if a.overpass_url:
    ox.settings.overpass_url = a.overpass_url
osm_ingest_local(place=a.place, filepath=os.path.expanduser(a.out))
print("done")

"""Step 1 (local): build the candidate pool of intersections for the comparison.

Keeps only intersections that have an OSM crossing edge within 25 m (the grow-cut
step needs an OSM edge to seed it), tags each with geography type and a
Google-tile-position proxy, and draws a pool per geography type.

Usage:
  uv run python 01_build_candidates.py \
      --intersections ../data/inputs/all_intersections.shp \
      --crosswalk-edges ../data/osm/crosswalk_edges_v2_0.shp \
      --out ../data/sample/candidates.csv --pool-per-group 300
"""

import argparse
import math

import geopandas as gpd
import pandas as pd

from cc_common import PRECISION, RADIUS_M, crosswalk_id

WORK_CRS = "EPSG:3435"           # IL State Plane East, US feet (project CRS)
RADIUS_FT = RADIUS_M * 3.28084
TILE_ZOOM = 19                   # tile grid used for the tile-position proxy


def tile_offset(lat, lon, z=TILE_ZOOM):
    """0 = tile centre, 1 = tile edge, for the Web-Mercator tile containing the point."""
    n = 2 ** z
    xt = (lon + 180.0) / 360.0 * n
    yt = (1.0 - math.asinh(math.tan(math.radians(lat))) / math.pi) / 2.0 * n
    fx, fy = xt % 1.0, yt % 1.0
    return 2.0 * max(abs(fx - 0.5), abs(fy - 0.5))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--intersections", required=True)
    p.add_argument("--crosswalk-edges", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--pool-per-group", type=int, default=300)
    p.add_argument("--seed", type=int, default=42)
    a = p.parse_args()

    pts = gpd.read_file(a.intersections).to_crs(WORK_CRS)
    edges = gpd.read_file(a.crosswalk_edges).to_crs(WORK_CRS)[["geometry"]]
    pts = pts.reset_index(drop=True)
    pts["row_id"] = pts.index

    near = gpd.sjoin_nearest(pts, edges, how="inner", max_distance=RADIUS_FT,
                             distance_col="dist_to_osm_crossing_ft")
    near = near.drop_duplicates("row_id")
    print(f"{len(near):,} of {len(pts):,} intersections have an OSM crossing within 25 m")

    # Geography type: use the project's 'type' column if present, else municipality name
    if "type" in near.columns:
        near["geography"] = near["type"].map(
            lambda t: "chicago" if str(t).lower() == "community area" else "suburban")
    else:
        near["geography"] = near["muni_name"].map(
            lambda m: "chicago" if str(m) == "Chicago" else "suburban")

    ll = near.to_crs("EPSG:4326")
    near["lat"] = ll.geometry.y.round(PRECISION)
    near["lon"] = ll.geometry.x.round(PRECISION)
    near["id"] = [crosswalk_id(la, lo) for la, lo in zip(near.lat, near.lon)]
    near["tile_offset"] = [tile_offset(la, lo) for la, lo in zip(near.lat, near.lon)]

    # shuffle, then take up to N per group (works on all pandas versions)
    pool = (near.sample(frac=1, random_state=a.seed)
                .groupby("geography").head(a.pool_per_group))
    keep = [c for c in ["id", "lat", "lon", "geography", "muni_name", "name", "geoid",
                        "tile_offset", "dist_to_osm_crossing_ft"] if c in pool.columns]
    pd.DataFrame(pool[keep]).drop_duplicates("id").to_csv(a.out, index=False)
    print(pool["geography"].value_counts().to_string())
    print(f"wrote {a.out}")


if __name__ == "__main__":
    main()

"""Draw the stratified evaluation sample and a separate prompt-pilot set (local).

Strata = geography (chicago/suburban) x canopy (high/low NDVI vegetation share in
the 4-band county clip) x Google tile position (centre/edge). Middle-tercile
canopy locations are dropped so the high/low contrast is clean.

The pilot set is drawn from the remaining candidates (never overlapping the
evaluation sample) and is used only to choose the SAM 3 text prompt.

Usage:
  uv run python 02_select_sample.py --candidates ../data/sample/candidates.csv \
      --ndvi ../data/sample/pool_ndvi.csv --n 150 --n-pilot 30 \
      --out ../data/sample/sample.csv --pilot-out ../data/sample/pilot.csv
"""

import argparse
import math

import pandas as pd


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--candidates", required=True)
    p.add_argument("--ndvi", required=True)
    p.add_argument("--n", type=int, default=150)
    p.add_argument("--n-pilot", type=int, default=30)
    p.add_argument("--out", required=True)
    p.add_argument("--pilot-out", required=True)
    p.add_argument("--seed", type=int, default=42)
    a = p.parse_args()

    cand = pd.read_csv(a.candidates)
    ndvi = pd.read_csv(a.ndvi)
    if "error" in ndvi:
        ndvi = ndvi[ndvi["error"].isna()]
    df = cand.merge(ndvi[["id", "veg_frac", "ndvi_mean"]], on="id", how="inner")

    lo, hi = df["veg_frac"].quantile([1 / 3, 2 / 3])
    df["canopy"] = pd.cut(df["veg_frac"], [-1, lo, hi, 2], labels=["low", "mid", "high"])
    df["tile_pos"] = (df["tile_offset"] >= df["tile_offset"].median()).map(
        {True: "edge", False: "centre"})
    strat = df[df["canopy"] != "mid"].copy()

    keys = ["geography", "canopy", "tile_pos"]
    n_cells = strat.groupby(keys, observed=True).ngroups
    per_cell = math.ceil(a.n / n_cells)
    # shuffle, then take up to per_cell from each stratum (works on all pandas versions)
    sample = (strat.sample(frac=1, random_state=a.seed)
                   .groupby(keys, observed=True).head(per_cell)
                   .reset_index(drop=True))
    print(sample.groupby(["geography", "canopy", "tile_pos"], observed=True).size().to_string())
    sample.to_csv(a.out, index=False)
    print(f"wrote {len(sample)} evaluation intersections -> {a.out}")

    # Pilot: any canopy level (mid included), never in the evaluation sample
    rest = df[~df["id"].isin(sample["id"])]
    pilot = (rest.sample(frac=1, random_state=a.seed + 1)
                 .groupby("geography").head(math.ceil(a.n_pilot / 2)))
    pilot.to_csv(a.pilot_out, index=False)
    print(f"wrote {len(pilot)} pilot intersections -> {a.pilot_out}")


if __name__ == "__main__":
    main()
